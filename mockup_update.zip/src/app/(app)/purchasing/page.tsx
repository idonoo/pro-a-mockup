import Link from "next/link";
import { CostForm } from "@/components/PurchasingForms";
import { PageHeader } from "@/components/ui";
import { r2 } from "@/lib/calc";
import { loadDb } from "@/lib/db";
import { fdate, fdt, fmt, makeT, matName, unitOf } from "@/lib/i18n-core";
import { BOM_KEYS } from "@/lib/master";
import { getLang, requireUser } from "@/lib/session";

export default async function Purchasing() {
  await requireUser("purchasing");
  const t = makeT(await getLang());
  const db = loadDb();
  const waiting = db.orders.filter((o) => o.status === "waiting_material");
  const shortage = Object.fromEntries(BOM_KEYS.map((k) => [k, r2(waiting.reduce((s, o) => s + (o.shortage?.[k] ?? 0), 0))]));
  const need = BOM_KEYS.filter((k) => shortage[k] > 0);
  const missing = db.receipts.filter((r) => r.cost === undefined);
  const recorded = db.receipts.filter((r) => r.cost !== undefined);
  const pendingFor = (id: string) => db.costChanges.some((c) => c.receiptId === id && c.status === "pending");
  const summary = (r: (typeof db.receipts)[number]) => `${r.id} · ${r.poNo || "—"} · ${matName(t, r.material, db.materials)} ${fmt(r.enteredQty)} ${r.enteredUnit}`;

  const table = (list: typeof db.receipts, withCost: boolean) => (
    <table className="w-full">
      <thead>
        <tr>
          <th className="th">{t("rc.id")}</th>
          <th className="th">{t("rc.date")}</th>
          <th className="th">{t("rc.poNo")}</th>
          <th className="th">{t("rc.material")}</th>
          <th className="th text-right">{t("rc.qty")}</th>
          <th className="th">{t("rc.supplier")}</th>
          {withCost && <th className="th text-right">{t("cost.cost")}</th>}
          <th className="th">{withCost ? t("cost.change") : t("cost.enter")}</th>
        </tr>
      </thead>
      <tbody>
        {list.map((r) => (
          <tr key={r.id}>
            <td className="td font-semibold">{r.id}</td>
            <td className="td whitespace-nowrap">{fdate(r.date)}</td>
            <td className="td">{r.poNo || "—"}</td>
            <td className="td">{matName(t, r.material, db.materials)}</td>
            <td className="td text-right whitespace-nowrap">{fmt(r.enteredQty)} {r.enteredUnit}<div className="text-sm text-slate-500">= {fmt(r.qtyKg)} {unitOf(r.material, db.materials)}</div></td>
            <td className="td">{r.supplier || "—"}</td>
            {withCost && <td className="td text-right whitespace-nowrap">{fmt(r.cost)} / {unitOf(r.material, db.materials)}</td>}
            <td className="td">
              <CostForm receiptId={r.id} current={r.cost} pending={pendingFor(r.id)} unit={unitOf(r.material, db.materials)} summary={summary(r)} />
            </td>
          </tr>
        ))}
        {list.length === 0 && <tr><td className="td text-center text-slate-500" colSpan={8}>{t("empty")}</td></tr>}
      </tbody>
    </table>
  );

  return (
    <>
      <PageHeader title={t("nav.purchasing")} sub={t("purch.sub")} />

      {need.length > 0 && (
        <div className="mb-6 rounded-2xl border-2 border-red-300 bg-red-50 p-5">
          <h2 className="text-2xl font-bold text-red-800">⚠ {t("stock.alert")}</h2>
          <p className="mt-1 text-xl">{need.map((k) => `${t(`mat.${k}`)} ${fmt(shortage[k])} kg`).join(" · ")}</p>
          <p className="mt-2 text-lg">
            {t("stock.alertOrders")}:{" "}
            {waiting.map((o) => (
              <Link key={o.id} href={`/orders/${o.id}`} className="mr-3 font-bold text-blue-800 underline">{o.id}</Link>
            ))}
          </p>
        </div>
      )}

      <section className="card mb-6 overflow-x-auto border-2 border-amber-300">
        <h2 className="mb-1 text-2xl font-bold">{t("cost.missingTitle")} ({missing.length})</h2>
        <p className="mb-3 text-base text-slate-500">{t("cost.missingHint")}</p>
        {table(missing, false)}
      </section>

      <section className="card mb-6 overflow-x-auto">
        <h2 className="mb-1 text-2xl font-bold">{t("cost.recordedTitle")} ({recorded.length})</h2>
        <p className="mb-3 text-base text-slate-500">{t("cost.recordedHint")}</p>
        {table(recorded, true)}
      </section>

      <section className="card overflow-x-auto">
        <h2 className="mb-3 text-2xl font-bold">{t("cost.log")}</h2>
        <CostLog changes={db.costChanges} />
      </section>
    </>
  );

  function CostLog({ changes }: { changes: typeof db.costChanges }) {
    return (
      <table className="w-full">
        <thead>
          <tr>
            <th className="th">{t("rc.date")}</th>
            <th className="th">{t("rc.id")}</th>
            <th className="th">{t("rc.material")}</th>
            <th className="th text-right">{t("cost.cost")}</th>
            <th className="th">{t("cost.requestedBy")}</th>
            <th className="th">{t("cost.approvedBy")}</th>
            <th className="th">{t("o.status")}</th>
          </tr>
        </thead>
        <tbody>
          {changes.slice(0, 15).map((c) => (
            <tr key={c.id}>
              <td className="td whitespace-nowrap">{fdt(c.requestedAt)}</td>
              <td className="td">{c.receiptId}</td>
              <td className="td">{matName(t, c.material, db.materials)}</td>
              <td className="td text-right whitespace-nowrap">{c.oldCost === undefined ? "—" : fmt(c.oldCost)} → {fmt(c.newCost)}</td>
              <td className="td">{c.requestedBy}</td>
              <td className="td">{c.auto ? t("cost.noApproval") : (c.decidedBy ?? "—")}</td>
              <td className="td">{t(`cost.st.${c.status}`)}</td>
            </tr>
          ))}
          {changes.length === 0 && <tr><td className="td text-center text-slate-500" colSpan={7}>{t("empty")}</td></tr>}
        </tbody>
      </table>
    );
  }
}
