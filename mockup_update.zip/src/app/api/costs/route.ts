import { apiUser, json, unauthorized } from "@/lib/api";
import { mutate } from "@/lib/db";
import * as wf from "@/lib/workflow";

// Unit cost of goods receipts: purchasing enters / requests a change, the executive decides
export async function POST(req: Request) {
  const user = await apiUser();
  if (!user) return unauthorized();
  const b = await req.json();
  return json(
    mutate((db): wf.Result => {
      switch (b.action) {
        case "set":
          return wf.setReceiptCost(db, user, b.receiptId, Number(b.cost));
        case "request_change":
          return wf.requestCostChange(db, user, b.receiptId, Number(b.cost));
        case "approve":
          return wf.decideCostChange(db, user, b.changeId, true);
        case "reject":
          return wf.decideCostChange(db, user, b.changeId, false);
        default:
          return { ok: false, errors: ["err.generic"] };
      }
    }),
  );
}
