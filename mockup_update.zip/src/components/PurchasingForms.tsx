"use client";
import { useState } from "react";
import { fmt } from "@/lib/i18n-core";
import { useRun } from "./ActionButton";
import { ConfirmButton } from "./ConfirmButton";
import { useT } from "./I18nProvider";

/** Purchasing: first cost entry for a receipt (no approval) or a change request (needs the executive). */
export function CostForm({
  receiptId,
  current,
  pending,
  unit,
  summary,
}: {
  receiptId: string;
  current?: number;
  pending?: boolean;
  unit: string;
  summary: string; // "RC-0001 · PO-… · Steel 500 kg"
}) {
  const t = useT();
  const run = useRun();
  const [v, setV] = useState("");
  const change = current !== undefined;
  if (pending) return <span className="text-lg font-semibold text-amber-700">{t("cost.pendingBadge")}</span>;
  return (
    <div className="flex items-center gap-2">
      <input className="input !min-h-11 w-40" type="number" min={0} step="any" placeholder={change ? t("cost.newCost") : t("cost.enter")} value={v} onChange={(e) => setV(e.target.value)} />
      <ConfirmButton
        label={change ? t("cost.requestChange") : t("cost.save")}
        variant={change ? "ghost" : "primary"}
        className="!min-h-11 !px-4 !text-base"
        disabled={!(Number(v) > 0)}
        spec={{
          title: change ? t("confirm.costChange") : t("confirm.costSet"),
          lines: [
            summary,
            change ? `${t("cost.cost")}: ${fmt(current)} → ${fmt(Number(v))} / ${unit}` : `${t("cost.cost")}: ${fmt(Number(v))} / ${unit}`,
          ],
          warning: change ? t("confirm.costChangeWarn") : undefined,
        }}
        run={run("/api/costs", { action: change ? "request_change" : "set", receiptId, cost: Number(v) }, { after: () => setV("") })}
      />
    </div>
  );
}
