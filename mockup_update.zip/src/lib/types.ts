export type Role = "sales" | "approver" | "production" | "store" | "purchasing" | "exec";
export type Lang = "th" | "en";
export type Spec = "tis" | "innovation";
export type BomKey = "steel" | "glue" | "pe" | "moisture" | "masterbatch";
export type MaterialKey = string; // BomKey or a custom material key
export type Qty = Record<BomKey, number>; // BOM quantities (core 5 materials)
export type Amounts = Record<string, number>; // any material, sparse

export type OrderStatus =
  | "pending_approval"
  | "rejected"
  | "waiting_material"
  | "waiting_production"
  | "in_production"
  | "qc_done"
  | "ready"
  | "delivered"
  | "completed";

export interface User {
  id: string;
  name: string;
  role: Role;
}

export interface Attachment {
  name: string;
  size: number;
}

export interface Material {
  key: MaterialKey;
  onHand: number; // in `unit`
  reserved: number;
  avgPrice: number; // baht per unit
  unit: string; // base unit
  category: "bom" | "other" | "spare";
  altUnit?: { th: string; en: string; factor: number }; // e.g. 1 bag = 25 kg
  custom?: boolean; // added by purchasing / executive; not part of the BOM formulas
  nameTh?: string;
  nameEn?: string;
}

/** Warehouse books the receipt without a price; purchasing fills `cost` (per base unit) afterwards. */
export interface Receipt {
  id: string;
  at: string;
  by: string;
  date: string; // date received
  material: MaterialKey;
  qtyKg: number; // quantity in the material's base unit
  enteredQty: number;
  enteredUnit: string;
  poNo: string;
  supplier: string;
  lot: string;
  cost?: number; // baht per base unit, set by purchasing
}

export interface CostChange {
  id: string;
  receiptId: string;
  material: MaterialKey;
  oldCost?: number;
  newCost: number;
  status: "pending" | "approved" | "rejected";
  requestedBy: string;
  requestedAt: string;
  decidedBy?: string;
  decidedAt?: string;
  auto?: boolean; // first entry: no approval needed
}

export interface MasterRow {
  steel: number;
  pe: number;
}
export interface MasterLog {
  at: string;
  by: string;
  spec: Spec;
  diameter: number;
  field: "steel" | "pe";
  from: number;
  to: number;
}

export interface Issue {
  id: string;
  requestedAt: string;
  requestedBy: string;
  items: Amounts;
  overBom: boolean;
  approval: "none" | "pending" | "approved" | "rejected";
  status: "requested" | "issued" | "rejected" | "cancelled"; // cancelled = replaced by a newer request
  edits?: { at: string; by: string; from: Amounts; to: Amounts }[];
  issuedAt?: string;
  issuedBy?: string;
  cost?: Amounts;
  costTotal?: number;
}

export interface Scrap {
  at: string;
  by: string;
  steelKg: number;
  plasticKg: number;
}

export interface Bom {
  perMeter: Qty & { total: number };
  required: Qty;
  requiredTotal: number;
  estCost: Qty;
  estCostTotal: number;
}

export interface HistoryItem {
  at: string;
  by: string;
  action: string; // i18n key
  note?: string;
}

export interface Order {
  id: string;
  customer: string;
  poRef: string;
  salesId: string;
  diameter: number;
  spec: Spec;
  totalLength: number;
  pieceLength: number;
  pieceCount: number;
  price: number;
  expenses: Expense[];
  deliveryDate: string;
  paymentDate: string;
  attachments: Attachment[];
  status: OrderStatus;
  createdAt: string;
  rejectReason?: string;
  bom?: Bom;
  shortage?: Qty;
  reservedRemaining?: Qty;
  issues: Issue[];
  scrap: Scrap[];
  fg?: { receivedAt: string; pieces: number; saleValue: number };
  deliveredAt?: string;
  paidAt?: string;
  history: HistoryItem[];
}

export interface Expense {
  name: string;
  amount: number;
}

export interface Settings {
  commissionBase: "sales" | "net";
  rateSales: number;
  rateNet: number;
  commissionTrigger: "approval" | "delivery" | "payment";
  approverSeesCost: boolean;
}

export interface Db {
  seq: number;
  users: User[];
  materials: Material[];
  receipts: Receipt[];
  costChanges: CostChange[];
  master: Record<Spec, Record<number, MasterRow>>;
  masterLog: MasterLog[];
  orders: Order[];
  settings: Settings;
}

export interface OrderInput {
  customer: string;
  poRef: string;
  diameter: number;
  spec: Spec;
  totalLength: number;
  pieceLength: number;
  pieceCount: number;
  price: number;
  expenses: Expense[];
  deliveryDate: string;
  paymentDate: string;
  attachments: Attachment[];
}
